﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IMS.CoreBusiness
{
    public enum InventoryTransactionType
    {
        PurchaseInventory = 1,
        ProduceProduct = 2
    }
}
