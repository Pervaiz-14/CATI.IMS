﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace IMS.WebApp.Data.Migrations
{
    public partial class InitialCreate : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
